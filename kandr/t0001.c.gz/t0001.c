// t0001.c
// K&R function definition

int foo(a,b,c)
  int a;
  float b;
  int *c;
{
  return a + (int)b + *c;
}
