// t0002.c
// implicit int

a;

int foo(register a)
{  
  return a;
}

