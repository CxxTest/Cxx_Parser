// t0003.c
// static and implicit int

static /*implicit-int*/ tinfoclose()
{
    return(0);
}
